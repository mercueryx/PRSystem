﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ERP_System
{
    public class ResourceModule
    {

        public static string ERP_con = "Data Source=128.30.0.7;Initial Catalog=ERPSystem;User ID=sa;";
        public static string HD_con = "Data Source=128.30.0.7;Initial Catalog=helpdesk;User ID=sa;";
        public static string IBAS_con = "Data Source=128.30.0.2;Initial Catalog=IBAS_LIVE;User ID=sa;";
    }
}